<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $title ?></title>
<link href="<?php echo base_url(); ?>asset/css/style.css" rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div id="Wrapper">
	