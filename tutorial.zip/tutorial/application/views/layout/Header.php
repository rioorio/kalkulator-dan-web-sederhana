<header>
	<div id="logo"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url();
?>asset/images/y.jpg" width="400" height="400"></a></div>
	<div id="nama"><span class="nama">PEMWEB</span><br>
	<span class="aipni">RIO FERDIANSYAH</span></div>
	</header>
	<nav>
		<ul>
		<li><a href="<?php echo base_url(); ?>">Home</a></li>
		<li><a href=""target="_blank">About us</a></li>
		<li><a href="<?php echo base_url(); ?>admin/login">Login</a></li>
		</ul>
		</nav>