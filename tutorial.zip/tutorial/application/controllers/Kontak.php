<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Kontak extends CI_Controller {
public function index() {
$data=array('title'=>'Contact Us',
'isi' =>'home/Kontak_view'
);
$this->load->views('layout/wrapper',$data);
}
}
?>